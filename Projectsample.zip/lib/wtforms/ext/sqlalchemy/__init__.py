import warnings

warnings.warn(
    'wtforms.ext.sqlalchemy is deprecated, and will be removed in WTForms 3.0. '
    'Instead transition to the excellent WTForms-Alchemy package: '
    'https://github.com/kvesteri/wtforms-alchemy',
    DeprecationWarning
)
